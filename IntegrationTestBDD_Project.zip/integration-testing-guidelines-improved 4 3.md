# Integration Testing Guidelines for Content Engagement Service

## 1. Overview

This document provides a standard approach for writing **integration test cases** for APIs using **Reqnroll** (SpecFlow successor), **BDD**, and containerized environments. Integration tests validate real-time behavior and interactions of API endpoints, business logic, data persistence, and external dependencies.

## 2. Why Integration Tests?

- Detect bugs in service interactions
- Catch API failures under realistic conditions
- Automate end-to-end system verification

## 3. Recommended Project Structure

```text
tests/
├── Relias.ContentEngagementService.Integration.Tests/
│   ├── Features/          # Gherkin feature files
│   ├── StepDefinitions/   # Reqnroll step implementations
│   ├── SharedDefinitions/ # Reusable step definitions
│   ├── Context/           # Test context objects
│   ├── Utilities/         # Test utilities
```

## 4. What to Cover in Integration Tests

- **Happy Path**: Successful API response with valid input
- **Error Handling**: Invalid input, missing data, constraint violations
- **Authentication & Authorization**: Role-based access, JWT validation
- **Data Persistence & Side Effects**: DB updates, external service calls
- **Edge Cases**: Empty fields, boundary values, large inputs
- **Service Interaction**: API-to-API/service calls

## 5. Core Testing Stack & Tools

- **xUnit**: Primary test framework
- **Reqnroll**: BDD testing with Gherkin syntax (`Given`, `When`, `Then`)
- **Microsoft.AspNetCore.Mvc.Testing**: In-memory API testing
- **Testcontainers**: Container-based infrastructure (Docker)
- **FluentAssertions**: Readable assertions
- **Moq**: Mocking framework for dependencies
- **Language**: Python / JavaScript / C#
- **Tools**: Postman, Docker, Azure Testcontainers,

### Key NuGet Packages

```xml
<PackageReference Include="Microsoft.AspNetCore.Mvc.Testing" Version="8.0.8" />
<PackageReference Include="Reqnroll.xUnit" Version="2.1.0" />
<PackageReference Include="Testcontainers.MsSql" Version="3.10.0" />
<PackageReference Include="FluentAssertions" Version="6.12.0" />
```

## 6. Creating and Managing Reqnroll Projects

**Install Reqnroll templates:**
```bash
dotnet new install Reqnroll.Templates.DotNet
```

**Add Reqnroll to an existing project:**
```bash
dotnet add package Reqnroll.xUnit
```

## 7. Example Gherkin Scenario and Step Definition

**Feature file example:**
```gherkin
Feature: Assignment Creation
  As an administrator
  I want to create a new assignment
  So that users can complete required training

  Scenario: Administrator creates a valid assignment
    Given an administrator is authenticated
    And the assignment data is valid
    When the administrator creates the assignment
    Then the assignment is saved in the database
    And the API returns a success response
```

**Step definition example:**
```csharp
[Given("an administrator is authenticated")]
public void GivenAdministratorIsAuthenticated()
{
    // Setup JWT token for admin
}

[When("the administrator creates the assignment")]
public async Task WhenAdministratorCreatesAssignment()
{
    // Call API endpoint
}

[Then("the assignment is saved in the database")]
public async Task ThenAssignmentIsSavedInDatabase()
{
    // Assert DB state
}
```

## 8. Gherkin Scenario Best Practices

- Write in plain language
- Focus on behavior, not implementation
- Use Background for common steps
- Limit scenarios to 5-7 steps
- Write independent scenarios
- Cover both positive and negative cases
- Use reusable steps
- Avoid duplication
- Use scenario outlines for parameterized tests
- Use tags for organization

## 9. Gherkin Bindings Best Practices

- Avoid scoped bindings
- Use lifecycle hooks
- Share data between bindings
- Use Scenario Context
- Avoid global state

## 10. Handling Flaky Tests and Retries

- Use xUnit's built-in retry logic or custom attributes for transient failures
- Investigate and fix root causes of flakiness (e.g., timing, environment)
- Avoid ignoring flaky tests; mark and track them for resolution

## 11. Do's and Don'ts for Gherkin Scenarios

### ✅ Do's
- Write in plain language
- Focus on behavior
- Use Background for shared steps
- Write independent scenarios
- Test positive and negative cases

### ❌ Don'ts
- Include technical details like "POST request"
- Describe system internals
- Repeat common steps in every scenario
- Rely on previous scenarios to set context
- Write only success cases

## 12. Testing Scope

- **API Layer**: Controller endpoints and HTTP responses
- **Application Layer**: Command/Query handlers and business logic
- **Infrastructure Layer**: Database operations and external service integrations
- **Cross-cutting Concerns**: Authentication, authorization, logging, error handling

## 13. Test Categories Overview

- **API Tests**: End-to-end HTTP request/response testing
- **Database Integration Tests**: Data persistence and retrieval
- **Service Integration Tests**: Business logic with external dependencies
- **Security Tests**: Authentication and authorization scenarios

## 14. Docker & Container-Based Integration Testing

### Why Use Docker/Testcontainers?
- Ensures consistent, isolated test environments for database and external dependencies
- Eliminates “works on my machine” issues by running tests against real containers
- Enables parallel and repeatable test runs in CI/CD pipelines

### Recommended Setup
- **Testcontainers** is used to spin up SQL Server (or other services) for each test run
- The integration environment should use `appsettings.Integration.json` for connection strings and service endpoints
- All containers should be started and stopped automatically via test hooks (`BeforeTestRun`, `AfterTestRun`)

### Example: SQL Server Container Setup
```csharp
private static readonly MsSqlContainer _sqlContainer = new MsSqlBuilder()
    .WithImage("mcr.microsoft.com/mssql/server:2022-latest")
    .WithWaitStrategy(Wait.ForUnixContainer().UntilPortIsAvailable(1433))
    .Build();

[BeforeTestRun]
public static async Task BeforeTestRun()
{
    await _sqlContainer.StartAsync();
    // ...setup code...
}

[AfterTestRun]
public static async Task AfterTestRun()
{
    await _sqlContainer.DisposeAsync().AsTask();
}
```

## 15. Best Practices
- Use official, versioned Docker images (e.g., `mcr.microsoft.com/mssql/server:2022-latest`)
- Always clean up containers after tests to avoid resource leaks
- Use environment variables or config files for connection strings
- For CI/CD, ensure the runner supports Docker (e.g., GitHub Actions: `sudo systemctl start docker`)
- For external dependencies (e.g., Redis, RabbitMQ), use corresponding Testcontainers libraries

## 16. CI/CD Integration Examples

### GitHub Actions Pipeline

```yaml
jobs:
  integration-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup .NET
        uses: actions/setup-dotnet@v3
        with:
          dotnet-version: '8.0.x'
      - name: Start Docker for Testcontainers
        run: |
          sudo systemctl start docker
          sudo docker info
      - name: Run Integration Tests
        run: dotnet test tests/Relias.ContentEngagementService.Integration.Tests/ --verbosity normal
```

### Troubleshooting
- If containers fail to start, check Docker daemon status and image compatibility
- For Windows runners, ensure Docker Desktop is running and configured for Linux containers
- Use Testcontainers logs for debugging startup issues

## 17. Test Environment Setup & Teardown

- **Integration Environment**: 
  <!--Uses `appsettings.Integration.json`-->
- **Database**: SQL Server container with fresh schema per test run
- **Authentication**: Mocked JWT tokens for test scenarios
- **External Services**: Use test doubles or containerized services

**Setup and Teardown Strategy:**
- Use Reqnroll hooks for environment setup and cleanup:
 <!--> - `BeforeScenario`: Set base URI, configure headers/auth, insert test data
  - `AfterScenario`: Clean up inserted data, reset DB changes, log results for failed cases-->

## 18. Test Categories (Detailed)

### 1. Happy Path Tests
- Valid API requests with expected responses
- Successful CRUD operations
- Proper data validation and business rule enforcement

### 2. Edge Case Tests
- Empty result sets
- Maximum/minimum values
- Optional parameters
- Null or default values

### 3. Error Handling Tests
- Invalid input validation
- Database constraint violations
- External service failures
- Authentication/authorization failures

## 19. Test Data Management

**Strategy:**
1. Fresh database per test run
2. Seed data in Background steps
3. Isolated test data (unique identifiers)
4. Realistic, domain-appropriate values

## 20. Continuous Integration and Coverage

- Test execution in CI/CD
- Generate test reports in pipeline
- Track coverage metrics (e.g., with Coverlet or ReportGenerator)
- Monitor execution times
- Alert on failures

## 21. Best Practices

### Test Design Principles
1. Independence: Tests should not depend on other tests
2. Repeatability: Tests should produce consistent results
3. Fast Execution: Optimize for quick feedback
4. Clear Intent: Test names and scenarios should be descriptive
5. Maintainability: Keep tests simple and focused

### Naming Conventions
- Feature files: Use descriptive names reflecting business functionality
- Scenarios: Start with user role and action (e.g., "An administrator creates an assignment")
- Step definitions: Use clear, action-oriented method names

## 22. Common Patterns and Examples

- Pagination testing
- Filtering and sorting
- Test cleanup (ensure code and data are cleaned after each run)

 Audit Instructions:
1. You are an expert software architect and a seasoned software developer. Your primary goal is to develop project architecture/structure that adheres to industry best practices. Ensure that the generated architecture/structure is clean, debug-able, well-documented, efficient, and easy to maintain. 
2. Follow guidelines from the documents 'Development_Process-V2.0' and 'Solutioning-and-Design_Template-V4.0' from Knowledge section.

# Rules:
1. Refer design principles mentioned in the section 'Design Principles' while reviewing the code.
2. Rate each audit checkpoint as mentioned the section 'Rating'
3. Refer guidelines mentioned in the section 'General Instructions' while reviewing the code.
4. The audit report should be in the format mentioned in the section 'Integration Report'. Prepare a detailed Integration report containing all the extracted checkpoints and show the audit report table.
5. Audit checkpoints should be all the points which mentioned above with # numberings. Do not change the checkpoint text, use all the checkpoints AS it IS.
6. Share "Overall Verdict". Do not provide Recommendations section explicitly.
7. Dowload the reports in 'Reports' folder under Auditor folder.

# Design Principles:
1. Separation of Concerns
2. Don't Repeat Yourself (DRY) principle
3. KISS (Keep it Simple, Stupid) principle
4. SOLID principles
5. Adherence to programming language specific coding conventions

# General Instructions:
1. The input for the audit or code review will be code files or folders or .zip file. In case of .zip file, extract the contents then conduct review of all files.
2. Review each file against all audit checkpoints and highlight missing audit checkpoints filewise
3. The audit should maintain strict level of review and it should not be very lenient.

# Rating includes in Report:

1. How each checkpoint is evaluated:	
	🟢 Low → The input code adheres to best practices, performance, security guidelines and is efficient.
	⚠️ Medium → Code needs significant improvements to become maintainable and efficient.
	🔴 High → Code is not maintainable, not performant, exposes security risk, not extensible, and has gaps which can severely impact the functioning of the system.
	NA → The parameter is not relevant for the input code.

# Integration Report Tabular Format should be as following with the column names 'Integration Report'

1. Serial Number
2. Area
3. Current implementation
4. AI Observations
5. Priority
6. AI Recommendations
7. Code Example
8. File Names (the name of file where code is present or name of file where code needs to updated)

*This comprehensive guide provides the foundation for effective integration testing in the Content Engagement Service, ensuring reliable, maintainable, and thorough test coverage across all system components.*
