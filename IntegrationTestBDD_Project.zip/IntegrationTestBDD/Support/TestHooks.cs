using TechTalk.SpecFlow;

namespace IntegrationTestBDD.Support
{
    [Binding]
    public class TestHooks
    {
        [BeforeScenario]
        public void BeforeScenario()
        {
            Console.WriteLine("Before scenario setup");
        }

        [AfterScenario]
        public void AfterScenario()
        {
            Console.WriteLine("After scenario cleanup");
        }
    }
}
