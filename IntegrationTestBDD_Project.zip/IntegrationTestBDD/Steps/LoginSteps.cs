using TechTalk.SpecFlow;
using NUnit.Framework;

namespace IntegrationTestBDD.Steps
{
    [Binding]
    public class LoginSteps
    {
        [Given(@"I am on the login page")]
        public void GivenIAmOnTheLoginPage()
        {
            Console.WriteLine("Navigated to login page");
        }

        [When(@"I enter valid username and password")]
        public void WhenIEnterValidUsernameAndPassword()
        {
            Console.WriteLine("Entered valid credentials");
        }

        [When(@"I enter invalid username or password")]
        public void WhenIEnterInvalidUsernameOrPassword()
        {
            Console.WriteLine("Entered invalid credentials");
        }

        [When(@"I click the login button")]
        public void WhenIClickTheLoginButton()
        {
            Console.WriteLine("Clicked login button");
        }

        [Then(@"I should see the dashboard")]
        public void ThenIShouldSeeTheDashboard()
        {
            Console.WriteLine("Dashboard displayed");
            Assert.Pass();
        }

        [Then(@"I should see an error message")]
        public void ThenIShouldSeeAnErrorMessage()
        {
            Console.WriteLine("Error message displayed");
            Assert.Pass();
        }
    }
}
